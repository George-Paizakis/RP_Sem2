/**
  ******************************************************************************
  * @file           : main.c
  * @author			: <your_name>
  * @version		: 1.0
  * @date			: <project_date>
  * @brief          : Main program body
  *
  * All additional configuration and implementation of features must be
  * implemented by the developer. Comments will need to be updated to include
  * the correct names, descriptions, and dates.
  *
  * Parameters may need to be changed for function prototypes and definitions
  * to correctly pass data for any process.
  *
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 Staffordshire University
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */


/* Definitions ---------------------------------------------------------------*/


/* Includes (Vendor Libraries, Standard Libraries, Personal Libraries) -------*/
#include "main.h"
#include <stdio.h>
#include "SerialIO/toca.h"
#include <stdlib.h>



/* Type Definitions ----------------------------------------------------------*/


/* Extern Function Prototypes ------------------------------------------------*/


/* Static Function Prototypes (Generated, Initialisation, Logic) -------------*/
static void SystemClock_Config(void);

static void init_i2c(void);
static void init_tim6(void);
static int program_loop(void);


/* Global Variables (Extern, Static) -----------------------------------------*/
static I2C_HandleTypeDef 	gI2C1;
static TIM_HandleTypeDef 	gTIM6;

static unsigned char gTxByte = 93;
static unsigned char gTskFin = 0;

/**
  * @brief  The application entry point.
  * @retval int - status code
  *
  * The developer is required to provide additional
  * configuration for the necessary features that will be enabled
  * for this application. Only the generated configuration is provided.
  */
int main(void)
{
	/* Local Variables */

	/* Configure and Init */
	HAL_Init();
	SystemClock_Config();
	init_i2c();
	init_tim6();
	init_serial_io();
	setvbuf(stdin, NULL, _IONBF, 0);

	printf("Hello World\r\n");

	HAL_NVIC_EnableIRQ(I2C1_EV_IRQn);
	HAL_NVIC_EnableIRQ(I2C1_ER_IRQn);

	return program_loop();
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  __HAL_RCC_I2C1_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = 		RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = 				RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = 			RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = 		RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 				4;
  RCC_OscInitStruct.PLL.PLLN = 				128;
  RCC_OscInitStruct.PLL.PLLP = 				RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 				6;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = 			RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK|RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = 			RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = 		RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = 		RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = 		RCC_HCLK_DIV8;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4);
}


/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}
static void init_i2c(void)
{
	gI2C1.Instance = I2C1;
	gI2C1.Init.ClockSpeed = 400000;
	gI2C1.Init.DutyCycle = I2C_DUTYCYCLE_2;
	gI2C1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
	gI2C1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
	gI2C1.Init.OwnAddress1 = 0;
	gI2C1.Init.OwnAddress2 = 0;
	gI2C1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
	gI2C1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
	HAL_I2C_Init(&gI2C1);
}
static void init_tim6(void)
{
	/* Local Variables */
	TIM_MasterConfigTypeDef timMstrCfg = {0};

	gTIM6.Instance = 	TIM6;
	gTIM6.Init.Prescaler = (64000 - 1);
	gTIM6.Init.CounterMode = TIM_COUNTERMODE_UP;
	gTIM6.Init.Period = (65536) - 1;
	gTIM6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	HAL_TIM_Base_Init(&gTIM6);

	timMstrCfg.MasterOutputTrigger = TIM_TRGO_RESET;
	timMstrCfg.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	HAL_TIMEx_MasterConfigSynchronization(&gTIM6, &timMstrCfg);
}
/**
  * @brief  The program loop
  * @retval int - status code
  */
static int program_loop(void)
{
	/* Local Variables */
	unsigned char wait = 0;
	unsigned short period = 0;
	unsigned char count = 0;

	HAL_I2C_EnableListen_IT(&gI2C1);
	HAL_TIM_Base_Start(&gTIM6);

	/* Program Loop */
	for(;;)
	{
		if(gTskFin)
		{
			/* Start Wait */
			if(!wait)
			{
				period = gTIM6.Instance->CNT;
				wait = 1;
			}
			else
			{
				if((gTIM6.Instance->CNT - period) >= 10)
				{
					wait = 0;
					gTskFin = 0;

					if(HAL_I2C_EnableListen_IT(&gI2C1) != HAL_OK)
					{
						/* This would be an err and move into a safe state */
					}
				}
			}
		}
		if(count++ < 10)
		{
			gTxByte = count;
		}
		else
		{
			count = 0;
		}

	}

	return 0;
}
/******************************************************************* Interrupts */
/**
* @brief This function handles I2C1 event interrupt.
*/
void I2C1_EV_IRQHandler(void)
{
	HAL_I2C_EV_IRQHandler(&gI2C1);
}
/**
* @brief This function handles I2C1 error interrupt.
*/
void I2C1_ER_IRQHandler(void)
{
	HAL_I2C_ER_IRQHandler(&gI2C1);
}

/******************************************************************* Callbacks */

/**
* @brief Tx Transfer completed callback.
* @param hndI2C: Pointer to a I2C_HandleTypeDef structure
* @retval void
*/
void HAL_I2C_SlaveTxCpltCallback(I2C_HandleTypeDef *hndI2C)
{
	gTskFin = 1;
}

/**
* @brief Slave Address Match callback.
* @param hndI2C: Pointer to a I2C_HandleTypeDef structure
* @param transferDirection: Master request Transfer Direction (Write/Read)
* @param addrMatchCode: Address Match Code
* @retval void
*/
void HAL_I2C_AddrCallback(I2C_HandleTypeDef *hndI2C, uint8_t transferDirection, uint16_t addrMatchCode)
{
	HAL_I2C_Slave_Seq_Transmit_IT(&gI2C1, &gTxByte, 1, I2C_FIRST_AND_LAST_FRAME);
}
/**
* @brief I2C error callbacks.
* @param hndI2C: Pointer to a I2C_HandleTypeDef structure
* @retval void
*/
void HAL_I2C_ErrorCallback(I2C_HandleTypeDef *hndI2C)
{
	/* Realistically set an error flag and check this in an error handling function in the main */
	if(HAL_I2C_GetError(&gI2C1) == HAL_I2C_ERROR_BERR)
	{
		fprintf(stderr, "Busy error\r\n");
	}
}
