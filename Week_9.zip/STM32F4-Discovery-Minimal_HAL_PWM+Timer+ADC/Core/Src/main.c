/**
  ******************************************************************************
  * @file           : main.c
  * @author			: <your_name>
  * @version		: 1.0
  * @date			: <project_date>
  * @brief          : Main program body
  *
  * All additional configuration and implementation of features must be
  * implemented by the developer. Comments will need to be updated to include
  * the correct names, descriptions, and dates.
  *
  * Parameters may need to be changed for function prototypes and definitions
  * to correctly pass data for any process.
  *
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 Staffordshire University
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */


/* Definitions ---------------------------------------------------------------*/


/* Includes (Vendor Libraries, Standard Libraries, Personal Libraries) -------*/
#include "main.h"
#include "toca.h"
#include <math.h>
#include <stdio.h>

/* Type Definitions ----------------------------------------------------------*/


/* Extern Function Prototypes ------------------------------------------------*/


/* Static Function Prototypes (Generated, Initialisation, Logic) -------------*/
static void SystemClock_Config(void);

static int init_gpio_adc(void);
static int program_loop(void);


/* Global Variables (Extern, Static) -----------------------------------------*/
static ADC_HandleTypeDef gAdcIn;
static unsigned int gCount = 0;
static unsigned int gAccu = 0;

/**
  * @brief  The application entry point.
  * @retval int - status code
  *
  * The developer is required to provide additional
  * configuration for the necessary features that will be enabled
  * for this application. Only the generated configuration is provided.
  */
int main(void)
{
	/* Local Variables */

	/* Configure and Init */
	HAL_Init();
	SystemClock_Config();

	init_gpio_adc();
	init_serial_io();
	setvbuf(stdin, NULL, _IONBF, 0);
	HAL_NVIC_EnableIRQ(ADC_IRQn);

	return program_loop();
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  /* Specialised Clock Enable */
  __HAL_RCC_ADC1_CLK_ENABLE();
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = 		RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = 				RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = 			RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = 		RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 				4;
  RCC_OscInitStruct.PLL.PLLN = 				128;
  RCC_OscInitStruct.PLL.PLLP = 				RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 				6;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = 			RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK|RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = 			RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = 		RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = 		RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = 		RCC_HCLK_DIV8;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4);
}

static int init_gpio_adc()
{
/* Local Variables */
ADC_ChannelConfTypeDef adcChConf;
GPIO_InitTypeDef gpioConf = {0};
/*Configure GPIO pin : PA1 */
gpioConf.Pin = GPIO_PIN_1;
gpioConf.Mode = GPIO_MODE_ANALOG;
gpioConf.Pull = GPIO_NOPULL;
HAL_GPIO_Init(GPIOA, &gpioConf);
gAdcIn.Instance = ADC1;
gAdcIn.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV8;
gAdcIn.Init.Resolution = ADC_RESOLUTION_12B;
gAdcIn.Init.DataAlign = ADC_DATAALIGN_RIGHT;
gAdcIn.Init.ScanConvMode = DISABLE;
gAdcIn.Init.ContinuousConvMode = ENABLE;
gAdcIn.Init.EOCSelection = ADC_EOC_SEQ_CONV;
gAdcIn.Init.NbrOfConversion = 1;
gAdcIn.Init.DMAContinuousRequests = DISABLE;
HAL_ADC_Init(&gAdcIn);
adcChConf.Channel = ADC_CHANNEL_1;
adcChConf.Rank = 1;
adcChConf.SamplingTime = ADC_SAMPLETIME_480CYCLES;
HAL_ADC_ConfigChannel(&gAdcIn, &adcChConf);
return 0;
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}


/**
  * @brief  The program loop
  * @retval int - status code
  */
static int program_loop(void)
{
	/* Local Variables */
	unsigned int adcVal;
	float volt;
	float voltsPerBit = (3.3f/4095.0f);

	HAL_ADC_Start_IT(&gAdcIn);

	/* … Other logic … */


	/* Program Loop */
	for(;;)
	{
		if(gCount >= 256)
		{
			adcVal = gAccu >> 8;
			gCount = 0;
			gAccu = 0;

			volt = (adcVal * voltsPerBit);
			volt *= 100.0f;
			volt = (ceil(volt));
			volt /= 100.0f;

			printf("Current Value: %d\r\n", adcVal);
		}
	}

	return 0;
}

void ADC_IRQHandler(void)
{
 HAL_ADC_IRQHandler(&gAdcIn);
}
void HAL_ADC_ConvCpltCallback (ADC_HandleTypeDef* hadc)
{
gAccu += HAL_ADC_GetValue(&gAdcIn);
gCount++;
}
